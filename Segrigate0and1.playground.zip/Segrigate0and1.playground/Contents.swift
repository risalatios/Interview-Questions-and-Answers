import UIKit

// Segregate 0s and 1s in an array
/*
 
 Method 1 (Count 0s or 1s)
 Thanks to Naveen for suggesting this method.
 1) Count the number of 0s. Let count be C.
 2) Once we have count, we can put C 0s at the beginning and 1s at the remaining n – C positions in array.
 */

func segrigate0and1Method1(in array: [Int]) -> [Int] {
    var newArray = array
    var countZeros = 0
    for item in newArray {
        if item == 0 {
            countZeros += 1
        }
    }
    for i in 0..<countZeros {
        newArray[i] = 0
    }
    for i in countZeros..<newArray.count {
        newArray[i] = 1
    }
    return newArray
}
print(segrigate0and1Method2())
/*
 Method 2 (Use two indexes to traverse)
 Maintain two indexes. Initialize first index left as 0 and second index right as n-1.

 Do following while left < right
 a) Keep incrementing index left while there are 0s at it
 b) Keep decrementing index right while there are 1s at it
 c) If left < right then exchange arr[left] and arr[right]
 */

func segrigate0and1Method2(in array:[Int] = [0,1,1,0,1,1,0,0,1]) -> [Int] {
    var newArray = array
    var left = 0
    var right = array.count - 1
    while left < right {
        while left == 0, left < right {
            left += 1
        }
        
        while right == 1, left < right {
            right -= 1
        }
        
        if left < right {
            newArray[left] = 0
            newArray[right] = 1
            left += 1
            right -= 1
        }
    }
    
    return newArray
    
}


print(segrigate0and1Method1(in: [0,1,1,1,0,0,0,0,1,0,1]))
