import UIKit

protocol SalaryCalculator {
    func calculateSalary(hourlyRate: Double) -> Double
}


class ExampleSalaryCalculator: SalaryCalculator {
    func calculateSalary(hourlyRate: Double) -> Double {
        hourlyRate * 40 * 5
    }
}



class TaxDiscountSalaryDecorator: SalaryCalculator {
    let decoratee: SalaryCalculator
    
    init(_ decoratee: SalaryCalculator) {
        self.decoratee = decoratee
    }
    
    func calculateSalary(hourlyRate: Double) -> Double {
        applyDiscount(decoratee.calculateSalary(hourlyRate: hourlyRate))
    }
    
    func applyDiscount(_ baseSalary: Double) -> Double {
        baseSalary - (baseSalary * 0.15)
    }
}


class HealthCareDiscountSalaryDecorator: SalaryCalculator {
    let decoratee: SalaryCalculator
    
    init(_ decoratee: SalaryCalculator) {
        self.decoratee = decoratee
    }
    
    func calculateSalary(hourlyRate: Double) -> Double {
        applyDiscount(decoratee.calculateSalary(hourlyRate: hourlyRate))
    }
    
    func applyDiscount(_ baseSalary: Double) -> Double {
        baseSalary - 600
    }
}



//Implementation
let salaryCalculator = HealthCareDiscountSalaryDecorator(
                        TaxDiscountSalaryDecorator(
                            ExampleSalaryCalculator()))

salaryCalculator.calculateSalary(hourlyRate: 40)  // 6200
