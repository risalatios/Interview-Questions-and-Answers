import UIKit

var max_sofar  = 0
var c_max = 0

let arr = [-2, -3, 4, -1, -2, 1, 5, -3]

for item in arr {
 c_max += item
    if max_sofar < c_max {
        max_sofar = c_max
    }
    
    if c_max < 0 {
        c_max = 0
    }
}

print(max_sofar)

var max_so_far = arr[0]
var current_max = arr[0]

for item in arr {
    current_max = max(item, current_max + item)
    max_so_far = max(max_so_far, current_max)
}

print(max_so_far)
