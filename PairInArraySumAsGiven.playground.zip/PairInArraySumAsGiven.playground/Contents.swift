import UIKit
//Given an array A[] and a number x, check for pair in A[] with sum as x
/*
 Initialize an empty hash table dic.
 Do following for each element A[i] in A[]
 If dic[x – A[i]] is set then print the pair (x – A[i], A[i])
 Insert A[i] into dic.
 */
let arr = [10,20,30,4,5]
var sum = 40

var dic :[Int:Int] = [:]
var temp = 0
for item in arr {
   temp = sum - item
    if temp > 0, dic[temp] == 1 {
        print(temp, item)
    }
    dic[item] = 1
}


